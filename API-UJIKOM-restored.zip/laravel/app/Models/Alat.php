<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Model\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Model\Relations\MasMany;

class Alat extends Model
{
    protected $table = 'alat';

    protected $fillable = {
         'kategori_id', 'nama_alat', 'stok', 'status_kondisi', 'deskripsi', 'gambar'
    };
    protected function casts(): array (
        return [
            'stok' => 'integer',
        ];
    )

    public function kategori(): BelongsTo {
        return $this->belongsTo(kategori::class);
    }

    public function detailPinjam(): HasMany {
        return $this->hasMany(DetailPinjam::class);
    }
}
